package com.example.myapplication;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    private TextView usd, hnl, eur;
    private Button Convertbtn;
    private EditText Currencytxt;
    private Spinner Currencyspn;
    private int index = 0;
    private double usdValue, eurValue, hnlValue, dato;
    private String valor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Currencytxt = (EditText)findViewById(R.id.Currencytxt);
        usd = (TextView)findViewById(R.id.usd);
        hnl = (TextView)findViewById(R.id.hnl);
        eur = (TextView)findViewById(R.id.eur);
        Convertbtn = (Button)findViewById(R.id.Convertbtn);
        Currencyspn = (Spinner)findViewById(R.id.Currencyspn);

        ArrayAdapter <CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.currency, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        Currencyspn.setAdapter(adapter);

        Currencyspn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                index = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Convertbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(index == 0){
                    valor = Currencytxt.getText().toString();
                    dato = Double.parseDouble(valor);
                    usdValue = dato * 1;
                    eurValue = dato * 0.86;
                    hnlValue = dato * 24.04;

                    usd.setText(""+usdValue);
                    hnl.setText(""+hnlValue);
                    eur.setText(""+eurValue);
                }
                else
                if(index==1){
                    valor = Currencytxt.getText().toString();
                    dato = Double.parseDouble(valor);
                    eurValue = dato * 1;
                    hnlValue = dato * 27.88;
                    usdValue = dato * 1.16;

                    usd.setText(""+usdValue);
                    hnl.setText(""+hnlValue);
                    eur.setText(""+eurValue);

                }
                else
                if(index==2){

                    valor = Currencytxt.getText().toString();
                    dato = Double.parseDouble(valor);
                    hnlValue = dato * 1;
                    eurValue = dato * 0.036;
                    usdValue = dato * 0.042;

                    usd.setText(""+usdValue);
                    hnl.setText(""+hnlValue);
                    eur.setText(""+eurValue);
                }



            }
        });
    }

}
